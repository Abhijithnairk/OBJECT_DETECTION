# samsung charger > 2024-03-30 10:41am
https://universe.roboflow.com/rotech/samsung-charger

Provided by a Roboflow user
License: CC BY 4.0

